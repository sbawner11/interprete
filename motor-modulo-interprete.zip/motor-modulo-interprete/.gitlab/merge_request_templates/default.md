**1. ¿Qué hace este Merge Request? / ¿Por qué lo necesitamos?:**

*

**2. Asegúrese de haber marcado las casillas a continuación antes de enviar el Merge Request:**
- [ ] He revisado y actualizado los paquetes de trabajo relacionados en [OpenProject](https://openproject-gep.infotec.mx/projects/beca-rita-cetina)
- [ ] He actualizado correctamente el CHANGELOG y el archivo pom.xm o package.json
- [ ] He realizado el "Push" de todos los cambios a la rama adecuada.
- [ ] He ejecutado localmente y no hay error.
- [ ] No hay conflicto con la rama objetivo.
- [ ] Necesita alguna configuración adicional o ejecución de scripts.

**3. ¿Qué problema corrige este Merge Request?**


**4. ¿Dónde se puede descargar el documento de pruebas unitarias previas?**


**5. ¿Dónde se puede descargar el documento de pruebas unitarias posteriores?**


**6. CHANGELOG / Notas de lanzamiento**

Gracias por tu Merge Request!
